---
activation:
    mode: trigger
apiVersion: agent.meta/v1
id: logging-rules
uid: abe2d728-e100-473b-aa54-1956b85edb03
kind: policy
scope: project
title: Logging Rules
applies_when: Applies when writing Go code that includes logging statements
tags:
  - baseline

---
# ログ記述規範 (Logging Rules)

本規範は、ログの記述基準を定め、運用時の障害調査と開発時のデバッグを効率化することを目的とする。

## 1. ログレベルの使用基準

### 1.1 INFO (運用者向け -- 平時確認)

**定義**: システム管理者が、トラブルではない平時にでも確認しておきたいログ。正常に動作していることが分かるもの。

**出力すべき場面**:
- サーバー/コンポーネントの起動・終了
- 設定ファイルのロード完了と主要設定値のサマリ
- 外部接続の確立（DB、API、syslog）
- リクエスト受付のサマリ（詳細はDEBUG以下）

**出力してはいけないもの**:
- ループ内の反復ごとのログ
- 変数値のダンプ

### 1.2 WARN (運用者向け -- 警告)

**定義**: エラーではないが、エラーにつながる可能性がある望ましくない状態。

**出力すべき場面**:
- マージン付き閾値の逆転・超過
- スローダウンの検出
- リトライの発生（試行回数を含む）
- 継続可能な例外の発生
- ファイル読み取り失敗（フォールバックあり）
- レスポンスのフォーマット/バージョン不一致（互換性で読める場合）
- syslog 接続失敗によるフォールバック発生

### 1.3 ERROR (運用者向け -- 障害)

**定義**: 処理を続行できず諦めなければならない問題。

**必須ルール**: ERROR ログには**その時点で収集可能な有益情報を全て含める**。後から TRACE レベルにして再現するのでは機会を逃すため、ERROR ログ自体に詳細なコンテキストを含めること。

**含めるべき情報**:
- エラーメッセージとスタックトレース（利用可能な場合）
- リクエストの概要（URL、メソッド、モデル名）
- レスポンスの概要（ステータスコード、ボディの先頭 500 バイト）
- コンテキスト情報（セッションID、プロバイダー名、変換パス）
- 発生時のタイムスタンプ

**注意**: Fatal / os.Exit() のような強制終了は不要。あくまでその処理のエラーを通知する。

### 1.4 DEBUG (開発者向け -- フロー追跡)

**定義**: 何を処理しているかが分かるもの。外形からの観測だけで内部処理フローが理解できるようにする。

**出力すべき場面**:
- 関数のエントリ（主要な関数のみ。ユーティリティ関数は不要）
- 条件分岐の判定結果（例: "routing to openai provider", "using responses mode"）
- オブジェクトの生成・破棄（セッション作成、プロセス起動/終了）
- ルーティング決定の理由
- 設定値の適用結果

**パラメータ**: 処理を説明するための簡単なパラメータを含める。
```go
logger.Debug("routing request", "model", model, "provider", provider, "mode", mode)
```

**画面への出来事（events）**: 封筒の `data`（中身）は、どのレベルでもログに出さない。出すのは種類・対象・`trace_id`・件名など、中身以外の識別子だけにする。

**メール**: 宛先・件名・本文・SMTP 応答の文（宛先を含むことがある）は、どのレベルでも出さない。出すのはメール ID・種類・状態・試行回数・SMTP の応答番号・`trace_id` だけにする。不達と最終失敗は WARN にする。

### 1.5 TRACE (開発者向け -- データダンプ)

**定義**: DEBUG を補足する詳細データのダンプ。

**出力すべき場面**:
- JSON ボディの全文（リクエスト/レスポンス）
- HTTP ヘッダーの一覧
- SSE イベントの生データ
- 設定ファイルの全内容
- 変換前後のデータ比較
- CLI プロセスの stdout/stderr の生出力

**注意**: TRACE は大量のデータを出力するため、本番環境では通常無効にする。

## 2. コンポーネントタグ付けルール

すべてのコンポーネントは `WithComponent()` でタグ付けし、ログにコンポーネント名を含めること。

| コンポーネント | タグ名 |
|---|---|
| Tern コアサーバー | `tern` |
| LLM Gateway Proxy | `llmgateway` |
| Agent Service | `legalchk` |
| Coding Agent (Claude Code) | `claudecode` |
| Coding Agent (Codex) | `codex` |
| WebSocket Server | `wsserver` |
| Bifrost Driver | `bifrost-driver` |
| Config Loader | `config` |
| Vault | `vault` |
| 設計データベース CLI | `designdb` |
| 進捗報告書の道具 | `progress-report` |

## 3. フィールド命名規則

ログのキー/バリューフィールドには以下の命名規則を適用する:

- **スネークケース**を使用: `session_id`, `model_name`, `provider`
- **共通フィールド名**:
  - `trace_id`: W3C Trace Context の trace-id（32 桁の小文字 16 進数）。GUI サーバのリクエストと CLI の実行ごとに付ける。`logger.WithTrace(ctx)` で取得する
  - `session_id`: セッション識別子
  - `model`: モデル名
  - `provider`: プロバイダー名 ("anthropic", "openai")
  - `method`: HTTP メソッド
  - `path`: リクエストパス（クエリ文字列を除く）
  - `status`: HTTP ステータスコード
  - `duration_ms`: 処理時間（ミリ秒）
  - `error`: エラーメッセージ
  - `body_size`: ボディサイズ（バイト）
  - `attempt`: リトライ試行回数

### 3.1 リクエストと CLI 実行のログ

- **GUI サーバ**: 全リクエストを trace middleware で包み、完了時に INFO で 1 行出す。フィールド: `method`, `path`, `status`, `duration_ms`, `trace_id`
- **CLI の db コマンド** (`db setup`, `db migrate`, `db status`): 実行ごとに trace_id を発行し、以降のログに付ける
- **ジョブのワーカー / `jobs enqueue`**: ログに少なくとも `job_id`, `kind`, `tenant_id`, `attempts`, `trace_id` を付ける（機微や本文は載せない）
- **ファイル / アーカイブ**: ファイル名・オブジェクトキー・中身・SHA-256 の全文をログに出さない。識別子は `file_id` / `blob_id` / `size_bytes` などに限る

## 4. 実装における注意事項

- **DEBUG ログは積極的に挿入する**。外形からの観測だけで内部処理が追跡できる透明性を目標とする。
- **TRACE ログはデータダンプ専用**。DEBUG ログに変数の中身を書かず、TRACE に分離する。
- **ERROR ログは詳細に**。後で再現するのでは遅い。その時点の情報を全て含める。
- **INFO ログは控えめに**。ループ内やリクエストごとに大量のINFOを出さない。
