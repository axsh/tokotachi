---
activation:
    mode: trigger
apiVersion: agent.meta/v1
id: logging-rules
kind: policy
scope: project
title: Logging Rules
applies_when: Applies when writing Go code that includes logging statements
tags:
  - baseline

---
# ログ記述規範 (Logging Rules)

本規範は、ログの記述基準を定め、運用時の障害調査と開発時のデバッグを効率化することを目的とする。

## 1. ログレベルの使用基準

### 1.1 INFO (運用者向け -- 平時確認)

**定義**: システム管理者が、トラブルではない平時にでも確認しておきたいログ。正常に動作していることが分かるもの。

**出力すべき場面**:
- サーバー/コンポーネントの起動・終了
- 設定ファイルのロード完了と主要設定値のサマリ
- 外部接続の確立（DB、API、syslog）
- リクエスト受付のサマリ（詳細はDEBUG以下）

**出力してはいけないもの**:
- ループ内の反復ごとのログ
- 変数値のダンプ

### 1.2 WARN (運用者向け -- 警告)

**定義**: エラーではないが、エラーにつながる可能性がある望ましくない状態。

**出力すべき場面**:
- マージン付き閾値の逆転・超過
- スローダウンの検出
- リトライの発生（試行回数を含む）
- 継続可能な例外の発生
- ファイル読み取り失敗（フォールバックあり）
- レスポンスのフォーマット/バージョン不一致（互換性で読める場合）
- syslog 接続失敗によるフォールバック発生

### 1.3 ERROR (運用者向け -- 障害)

**定義**: 処理を続行できず諦めなければならない問題。

**必須ルール**: ERROR ログには**その時点で収集可能な有益情報を全て含める**。後から TRACE レベルにして再現するのでは機会を逃すため、ERROR ログ自体に詳細なコンテキストを含めること。

**含めるべき情報**:
- エラーメッセージとスタックトレース（利用可能な場合）
- リクエストの概要（URL、メソッド、モデル名）
- レスポンスの概要（ステータスコード、ボディの先頭 500 バイト）
- コンテキスト情報（セッションID、プロバイダー名、変換パス）
- 発生時のタイムスタンプ

**注意**: Fatal / os.Exit() のような強制終了は不要。あくまでその処理のエラーを通知する。

### 1.4 DEBUG (開発者向け -- フロー追跡)

**定義**: 何を処理しているかが分かるもの。外形からの観測だけで内部処理フローが理解できるようにする。

**出力すべき場面**:
- 関数のエントリ（主要な関数のみ。ユーティリティ関数は不要）
- 条件分岐の判定結果（例: "routing to openai provider", "using responses mode"）
- オブジェクトの生成・破棄（セッション作成、プロセス起動/終了）
- ルーティング決定の理由
- 設定値の適用結果

**パラメータ**: 処理を説明するための簡単なパラメータを含める。
```go
logger.Debug("routing request", "model", model, "provider", provider, "mode", mode)
```

### 1.5 TRACE (開発者向け -- データダンプ)

**定義**: DEBUG を補足する詳細データのダンプ。

**出力すべき場面**:
- JSON ボディの全文（リクエスト/レスポンス）
- HTTP ヘッダーの一覧
- SSE イベントの生データ
- 設定ファイルの全内容
- 変換前後のデータ比較
- CLI プロセスの stdout/stderr の生出力

**注意**: TRACE は大量のデータを出力するため、本番環境では通常無効にする。

## 2. コンポーネントタグ付けルール

すべてのコンポーネントは `WithComponent()` でタグ付けし、ログにコンポーネント名を含めること。

| コンポーネント | タグ名 |
|---|---|
| Tern コアサーバー | `tern` |
| LLM Gateway Proxy | `llmgateway` |
| Agent Service | `agentservice` |
| Coding Agent (Claude Code) | `claudecode` |
| Coding Agent (Codex) | `codex` |
| WebSocket Server | `wsserver` |
| Bifrost Driver | `bifrost-driver` |
| Config Loader | `config` |
| Vault | `vault` |

## 3. フィールド命名規則

ログのキー/バリューフィールドには以下の命名規則を適用する:

- **スネークケース**を使用: `session_id`, `model_name`, `provider`
- **共通フィールド名**:
  - `session_id`: セッション識別子
  - `model`: モデル名
  - `provider`: プロバイダー名 ("anthropic", "openai")
  - `method`: HTTP メソッド
  - `path`: リクエストパス
  - `status`: HTTP ステータスコード
  - `duration_ms`: 処理時間（ミリ秒）
  - `error`: エラーメッセージ
  - `body_size`: ボディサイズ（バイト）
  - `attempt`: リトライ試行回数

## 4. 実装における注意事項

- **DEBUG ログは積極的に挿入する**。外形からの観測だけで内部処理が追跡できる透明性を目標とする。
- **TRACE ログはデータダンプ専用**。DEBUG ログに変数の中身を書かず、TRACE に分離する。
- **ERROR ログは詳細に**。後で再現するのでは遅い。その時点の情報を全て含める。
- **INFO ログは控えめに**。ループ内やリクエストごとに大量のINFOを出さない。
