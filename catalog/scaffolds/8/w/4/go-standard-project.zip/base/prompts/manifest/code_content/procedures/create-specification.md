---
apiVersion: agent.meta/v1
id: create-specification
kind: procedure
title: Create Specification
trigger:
    command: create-specification
description: Create a structured specification document capturing background, requirements, and verification scenarios.
tags:
  - baseline

---

# 仕様書作成ワークフロー

このワークフローは、ユーザーが述べた内容を元に、構造化された仕様書 (`.../ideas/.../XXX-{Name}.md`) を作成します。

## 1. 準備: ステータスとコンテキストの確認

1.  **ステータスの取得**:
    *   `scripts/utils/show_current_status.sh` を実行します。
    *   JSON出力から `phase`, `branch`, `next_idea_id` を取得します。
    *   以下、`[Phase]`, `[Branch]`, `[NextID]` とします。

## 2. 出力先の決定

1.  **ディレクトリの確定**:
    *   基本パス: `prompts/phases/[Phase]/branches/[Branch]/ideas/`
    *   例: `prompts/phases/001-webservices/branches/main/ideas/`
    *   このディレクトリが存在しない場合は作成します。
2.  **ファイル名の決定**:
    *   形式: `[NextID]-[名前].md`
    *   `[名前]` 部分は、仕様の内容を適切に表現する簡潔な名称を使用します（例: `Tokenizer`, `RateLimit-GlobalManagement`など）。

## 3. 仕様書の内容構成

仕様書には、以下の項目を最低限含める必要があります:

1.  **背景 (Background)**:
    *   なぜこの機能や変更が必要なのか。
    *   現在の課題や問題点。
    *   わかる範囲で記載します（不明な場合は省略可）。
2.  **要件 (Requirements)**:
    *   実現すべき機能や満たすべき条件。
    *   具体的な振る舞いや制約事項。
    *   必須要件と任意要件を明確に区別します。
3.  **実現方針 (Implementation Approach)**:
    *   どのような技術やアーキテクチャで実現するか。
    *   主要なコンポーネントやモジュールの概要。
    *   設計上の重要な決定事項。
4.  **検証シナリオ (Verification Scenarios)**:
    *   **重要 (Preserve Details)**: ユーザーが具体的な手順、条件、またはテストシナリオ（例: 「(1)○○して(2)××する」）を提示した場合は、**要約したり「要件」に丸め込んだりせず、ここにそのままの粒度で転記・整理してください。**
    *   ここは「何をもって完了とするか」の具体的なイメージを共有する場所です。
    *   形式: 番号付きリストでの時系列記述を推奨します。
5.  **テスト項目 (Testing for the Requirements)**:
    *   要件が実現されたと確認するための、**自動化された検証手順**を記載します。
    *   **重要 (Mandatory Automated Verification)**:
        *   手動確認（「画面を目視で確認」など）だけの計画は許可されません。
        *   必ずプロジェクト標準のスクリプトを使用した検証コマンドを明記してください。
    *   どの要件を、どのスクリプト/テストケースで検証するかを対比して記述します。
    *   **ビルド・全体検証の書き方**:
        *   **ビルド**: `scripts/process/build.sh` を記載します（全体ビルド＋単体テスト）。
        *   **統合テスト**: `scripts/process/integration_test.sh` を記載しますが、**オプションなしでの実行を推奨しません**。以下のガイドラインに従ってください。
    *   **`integration_test.sh` の実行戦略**:
        *   オプションなしで実行すると全カテゴリの統合テストが長時間実行され、不安定なテストも含まれるため、開発中の検証には不向きです。全カテゴリ一括実行は Nightly build 等の用途に留めてください。
        *   仕様書では、**影響範囲を分析した上で、`--categories` や `--specify` オプションを使った具体的な実行コマンドを複数記述する**こと。
        *   利用可能なカテゴリ: `common`, `llm`, `taskengine`, `template`, `gui`
        *   `--specify "REGEX"` で特定テストに絞り込むことも可能です。
        *   記述例:
            ```
            ### ビルド・全体検証
            
            1. ビルド＋単体テスト:
               scripts/process/build.sh
            
            2. バックエンド統合テスト（共通機能のリグレッション確認）:
               scripts/process/integration_test.sh --categories "common"
            
            3. GUI 統合テスト（UI 変更の確認）:
               scripts/process/integration_test.sh --categories "gui" --specify "SettingsGear|MailPost"
            ```
        *   仕様の影響範囲に応じて、実行するカテゴリと `--specify` の対象を適切に選定します。影響しないカテゴリは含めないでください。

## 4. 仕様書の作成と保存

1.  **ユーザーとの対話**:
    *   ユーザーが述べた内容を注意深く聞き、必要に応じて質問して詳細を明確にします。
    *   背景、要件、実現方針、**および具体的な検証シナリオ**の4つの観点で情報を整理します。
    *   **警告**: ユーザーが具体的な手順（Scenario）を提示している場合、それを勝手に抽象的な「機能要件」だけに変換して手順を捨ててはいけません。必ず「検証シナリオ」として詳細を残してください。
2.  **マークダウン形式での作成**:
    *   見出し、リスト、テーブルなどを適切に使用して読みやすく構造化します。
    *   コードサンプルやAPIの例があれば、コードブロックで記載します。
    *   Mermaid図などを用いて、アーキテクチャや処理フローを視覚化することも推奨されます。
3.  **ファイルの保存**:
    *   決定したファイル名で、指定されたディレクトリにファイルを保存します。

## 5. 完了確認

1.  **内容のレビュー**:
    *   作成した仕様書が、背景・要件・実現方針の観点をカバーしているか確認します。
2.  **ドキュメントの Git コミット**:
    *   作成・更新した仕様書ファイルを `git add` → `git commit` してください。
    *   コミットメッセージ例: `docs: add specification XXX-Name`
    *   修正が複数回あった場合は、最終版をまとめてコミットしても構いません。
    ```bash
    git add prompts/phases/[Phase]/branches/[Branch]/ideas/[ファイル名]
    git commit -m 'docs: add specification XXX-Name'
    ```
3.  **ファイルパスの提示**:
    *   作成したファイルへのリンクをユーザーに提示します。
        * 「file://プロジェクトルートからの相対パス」を用いること
    *   **フェーズ移行**: 次のステップ（実装計画の作成等）に進むのは、ユーザーが明示的に指示した場合のみです。勝手に `create-implementation-plan` に進まないでください。
