---
apiVersion: agent.meta/v1
id: execute-implementation-plan
kind: procedure
title: Execute Implementation Plan
trigger:
    command: execute-implementation-plan
description: Execute an approved implementation plan following TDD workflow with incremental commits and verification.
tags:
  - baseline

---

# 実装実行ワークフロー

実装計画書 (`.../plans/.../XXX.md`) に基づき、コーディングルールとテストルールを遵守して実装を行う。

## 1. 入力とルールの確認

1.  **入力ファイルの特定**:
    *   ユーザーが指定したファイル、または現在エディタで開いているファイルを「実装計画書」として扱う。
2.  **ルールの読み込み**:
    *   `{{policy:coding-rules}}` (コーディングルール)
    *   `{{policy:testing-rules}}` (テスト実施ルール)
    *   `{{policy:logging-rules}}` (ログ記述ルール)

## 2. 実装の実行

1.  **計画の読み込み**:
    *   実装計画書の内容を読み、変更対象のファイルや具体的な変更内容を把握する。
    *   計画が複数ファイルに分割されている場合は、すべての計画ファイルを確認する。
2.  **進捗の追跡**:
    *   `[ ]` → `[/]` (進行中) → `[x]` (完了) でチェックボックスを更新する。
3.  **コーディング**:
    *   計画書の手順に従ってコードを記述・修正する。
    *   `{{policy:coding-rules}}` のスタイルや設計原則を厳守する。
    *   `{{policy:logging-rules}}` のレベル基準に従い、DEBUG ログを積極的に挿入する。
4.  **こまめな Git コミット**:
    *   各ステップ完了ごとに `git add` → `git commit` を実施する。
    *   コミットルールの詳細は `instructions.md` の「Git 操作ルール」を参照。

## 2.5 E2Eテストの実装

実装計画の Verification Plan に **E2E Tests** セクションがある場合、テスト実行の**前に**、E2Eテストコードを実装する。

> [!CAUTION]
> **「手動でコマンドを実行して動作確認する」ことは、E2Eテストコードの代替にはならない。**
> 手動確認で得られた知見は、必ずテストコードとして残し、リグレッションテストとして機能するようにすること。

1.  **既存インフラの確認**:
    *   `tests/` 配下の既存E2Eテストファイルを確認し、ヘルパー関数を把握する。
2.  **E2Eテストコードの実装**:
    *   実装計画の Verification Plan に記載されたE2Eテストケースをコードとして実装する。
3.  **コミット**:
    *   `git add && git commit` でE2Eテストコードをコミットする。

## 3. テストと検証

テスト実施の詳細ルール（実行順序、修正ループ、タイムアウト方針等）は `{{policy:testing-rules}}` を参照。

### 3.1 テスト実施の順序

1.  **Build & Unit Test (必須)**:
    *   `./scripts/process/build.sh` を実行する。
    *   **失敗時は次のステップに進んではならない。**
2.  **統合テストの実施**:
    *   Build 成功後のみ実行する。
    *   `./scripts/process/integration_test.sh --categories "xxx"` で関連カテゴリを指定実行する。
    *   **失敗時は testing-rules.md Section 3 の修正ループに従い修正する。**

### 3.2 修正と再テスト

> [!CAUTION]
> **NEVER IGNORE FAILURES**: ビルドやテストの失敗を無視してタスクを完了させることは禁止。

修正ループの詳細手順は `{{policy:testing-rules}}` Section 3 を参照。
「後で直す」は禁止。その場で修正し、コミットする。


### 3.3 遠方知識の記録 (Far-Knowledge Recording)

> [!CAUTION]
> **省略禁止**: git push の前に、このステップを**必ず**実行してください。
> 遠方知識に該当する変更がない場合でも、判定プロセスは実行し、
> 「no update」の報告を出してから次に進んでください。

全てのビルドとテストが成功し、コミットが完了した後、git push の**前に**、
**record-far-knowledge** スキルに従って遠方知識の記録を行ってください。

体系化・スキル化は別途 **systematize-far-knowledge** ワークフローで実施します。

## 4. Git Push

全てのビルドとテストが成功した後、`git push` を実施する。
テストが失敗している状態ではプッシュしない。